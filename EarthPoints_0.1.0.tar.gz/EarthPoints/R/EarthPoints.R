#' EarthPoints: Compute shots on the Earth
#'
#' Convert to different coordinate system and compute different shots
#'
#' @docType package
#' @name EarthPoints
"_PACKAGE"
